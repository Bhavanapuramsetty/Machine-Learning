from flask import Flask, request, jsonify, render_template
import numpy as np
import pickle

# Load the trained model
model = pickle.load(open('xgboost_model.pkl', 'rb'))

# Initialize Flask application
app = Flask(__name__)

# Main route to render the HTML form
@app.route('/')
def home():
    return render_template('index.html')

# Prediction route to handle form submission
@app.route('/predict', methods=['POST'])
def predict():
    # Retrieve data from form submission
    year = int(request.form['year'])
    month = int(request.form['month'])
    day = int(request.form['day'])
    hour = int(request.form['hour'])
    borough = int(request.form['borough'])  # Assuming borough is encoded as an integer

    # Prepare the features array with the correct number of inputs
    features = np.array([[year, month, day, hour, borough]])

    # Make the prediction
    prediction = model.predict(features)

    # Render the HTML with prediction result
    return render_template('index.html', prediction_text=f'Predicted Traffic Volume: {prediction[0]:.2f} vehicles')

# Run the Flask app
if __name__ == "__main__":
    app.run(debug=True)
